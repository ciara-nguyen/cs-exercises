public class HelloGoodbye {
    public static void main(String[] args) {
        //Declaration 2 strings
        String a=args[0];
        String b=args[1];
        //Prints "Hello" and "goodbye" to the terminal window
        System.out.println ("Hello "+a+" and "+b);
        System.out.println("Goodbye "+b+" and "+a);
    }
}
